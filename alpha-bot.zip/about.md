# α Alpha Bot

A tiny **record & replay** bot for Geometry Dash. Windows, macOS, iOS and Android.

## Use
Pause the game, tap the **α** button, then:
- **Record** restarts the level and records your taps
- **Replay** restarts the level and plays the macro back
- **Save / Load / Delete** manage macros of the current level
- **Render** (optional) records the replay to an `.mp4` — needs the *FFmpeg API* mod (Windows / macOS / Android)

## Fixes (all on by default)
- **Frame fix** — fixed 60 Hz update step while recording/replaying, so results don't depend on your FPS
- **Input fix** — duplicate/stray presses are dropped, live taps are blocked during replay, held buttons are released when a replay ends
- **Practice fix** — rewinding to a checkpoint trims the macro to that point

## Credits
- **idk** — Alpha Bot
- **fig** — creator of zBot, which inspired this mod

Independent implementation, contains no zBot code. Macros are saved as `.abr` files in the mod's save folder.
Please don't submit botted runs as legit completions.
