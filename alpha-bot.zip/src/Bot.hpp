#pragma once

#include <Geode/Geode.hpp>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

#include "Render.hpp"

namespace ab {

using namespace geode::prelude;
namespace fs = std::filesystem;

enum class Mode { Idle, Record, Play };

// One input event, stamped with the physics step it happened on.
struct Action {
    uint32_t frame;
    uint8_t button;  // 1 = jump, 2/3 = platformer left/right
    bool down;
    bool p1;
};

constexpr float kStep = 1.f / 60.f;  // frame fix: fixed update step
constexpr uint32_t kTail = 480;      // render keeps going this many steps after the last input

class Bot {
public:
    static Bot& get() {
        static Bot inst;
        return inst;
    }

    // ---- state ----
    Mode mode = Mode::Idle;
    std::vector<Action> actions;
    uint32_t frame = 0;
    size_t cursor = 0;
    bool finished = false;   // playback has consumed every action
    bool injecting = false;  // true while the bot itself presses buttons
    bool stepped = false;    // a physics step ran during the current scheduler update
    bool held[4][2] = {};    // [button][player2?]
    float acc = 0.f;
    std::unordered_map<void*, uint32_t> checkpoints;

    // ---- options ----
    bool frameFix = true;
    bool inputFix = true;
    bool practiceFix = true;
    bool renderOpt = false;  // user wants a video when replaying

    // ---- render ----
    bool rendering = false;
    Renderer renderer;

    Ref<CCLabelBMFont> hud;

    Bot() {
        auto m = Mod::get();
        frameFix = m->getSavedValue<bool>("frame-fix", true);
        inputFix = m->getSavedValue<bool>("input-fix", true);
        practiceFix = m->getSavedValue<bool>("practice-fix", true);
    }

    void saveOptions() {
        auto m = Mod::get();
        m->setSavedValue<bool>("frame-fix", frameFix);
        m->setSavedValue<bool>("input-fix", inputFix);
        m->setSavedValue<bool>("practice-fix", practiceFix);
    }

    // ------------------------------------------------------------------
    // session control
    // ------------------------------------------------------------------
    void begin(Mode m) {
        mode = m;
        rendering = false;
        if (m == Mode::Play && renderOpt && Renderer::available()) {
            renderer.begin(replayDir().parent_path() / "renders" / (levelKey() + "_" + timestamp() + ".mp4"));
            std::error_code ec;
            fs::create_directories(renderer.output().parent_path(), ec);
            rendering = true;
        }
        resetAttempt();
    }

    void endSession() {
        if (rendering) {
            renderer.stop();
            rendering = false;
        }
        mode = Mode::Idle;
        updateHud();
    }

    void fullReset() {
        endSession();
        actions.clear();
        hud = nullptr;
        frame = 0;
        cursor = 0;
    }

    // Called whenever the attempt restarts from the very beginning.
    void resetAttempt() {
        frame = 0;
        cursor = 0;
        acc = 0.f;
        checkpoints.clear();
        std::memset(held, 0, sizeof(held));
        if (mode == Mode::Record) actions.clear();
        finished = mode != Mode::Play || actions.empty();
        updateHud();
    }

    uint32_t lastFrame() const { return actions.empty() ? 0 : actions.back().frame; }

    // ------------------------------------------------------------------
    // INPUT FIX
    // Returns false for redundant events (press while already pressed,
    // release while already released) so stray taps never get recorded
    // or replayed.
    // ------------------------------------------------------------------
    bool accept(bool down, int button, bool p1) {
        bool& h = held[std::clamp(button, 0, 3)][p1 ? 1 : 0];
        if (inputFix && h == down) return false;
        h = down;
        return true;
    }

    // Releases everything that is still held (end of replay, rewind...).
    void releaseAll(GJBaseGameLayer* gl) {
        for (int b = 1; b <= 3; b++) {
            for (int p = 0; p < 2; p++) {
                if (!held[b][p]) continue;
                injecting = true;
                gl->handleButton(false, b, p == 1);
                injecting = false;
            }
        }
    }

    // ------------------------------------------------------------------
    // PRACTICE FIX
    // Called after a checkpoint has been loaded.
    // ------------------------------------------------------------------
    void rewind(uint32_t to) {
        frame = to;
        std::memset(held, 0, sizeof(held));

        if (mode == Mode::Record && practiceFix) {
            while (!actions.empty() && actions.back().frame >= to) actions.pop_back();

            // the respawn drops the player's input, so close anything still open
            std::map<std::pair<int, bool>, bool> open;
            for (auto const& a : actions) open[{a.button, a.p1}] = a.down;
            for (auto const& [key, isDown] : open) {
                if (isDown) actions.push_back({to, static_cast<uint8_t>(key.first), false, key.second});
            }
        } else if (mode == Mode::Play) {
            cursor = 0;
            while (cursor < actions.size() && actions[cursor].frame < to) cursor++;
            finished = cursor >= actions.size();
        }
        updateHud();
    }

    // ------------------------------------------------------------------
    // HUD
    // ------------------------------------------------------------------
    void updateHud() {
        if (!hud) return;
        hud->setVisible(mode != Mode::Idle);
        if (mode == Mode::Idle) return;
        char const* name = rendering ? "RENDER" : mode == Mode::Record ? "REC" : "PLAY";
        hud->setString(fmt::format("alpha | {} | {}", name, frame).c_str());
    }

    // ------------------------------------------------------------------
    // replay files (.abr, plain text)
    // ------------------------------------------------------------------
    static std::string timestamp() {
        std::time_t t = std::time(nullptr);
        char buf[32];
        std::strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", std::localtime(&t));
        return buf;
    }

    std::string levelKey() {
        auto pl = PlayLayer::get();
        if (!pl || !pl->m_level) return "unknown";
        int id = pl->m_level->m_levelID.value();
        if (id > 0) return std::to_string(id);
        std::string name = pl->m_level->m_levelName;
        std::string out = "local_";
        for (char c : name) out += std::isalnum(static_cast<unsigned char>(c)) ? c : '_';
        return out;
    }

    fs::path replayDir() {
        auto dir = Mod::get()->getSaveDir() / "replays";
        std::error_code ec;
        fs::create_directories(dir, ec);
        return dir;
    }

    std::vector<fs::path> listReplays() {
        std::vector<fs::path> out;
        std::error_code ec;
        auto prefix = levelKey() + "_";
        for (auto const& e : fs::directory_iterator(replayDir(), ec)) {
            auto const& p = e.path();
            if (p.extension() != ".abr") continue;
            if (p.filename().string().rfind(prefix, 0) != 0) continue;
            out.push_back(p);
        }
        std::sort(out.begin(), out.end());
        return out;
    }

    bool save() {
        if (actions.empty()) return false;
        std::ofstream f(replayDir() / (levelKey() + "_" + timestamp() + ".abr"));
        if (!f) return false;
        f << "ALPHA1\n";
        for (auto const& a : actions) {
            f << a.frame << ' ' << int(a.button) << ' ' << (a.down ? 1 : 0) << ' ' << (a.p1 ? 1 : 0) << '\n';
        }
        return f.good();
    }

    bool load(fs::path const& path) {
        std::ifstream f(path);
        if (!f) return false;
        std::string header;
        std::getline(f, header);
        if (header.rfind("ALPHA1", 0) != 0) return false;

        std::vector<Action> out;
        uint32_t fr;
        int b, d, p;
        while (f >> fr >> b >> d >> p) {
            out.push_back({fr, static_cast<uint8_t>(b), d != 0, p != 0});
        }
        std::stable_sort(out.begin(), out.end(), [](Action const& x, Action const& y) { return x.frame < y.frame; });
        actions = std::move(out);
        return true;
    }

    bool remove(fs::path const& path) {
        std::error_code ec;
        return fs::remove(path, ec);
    }
};

}
