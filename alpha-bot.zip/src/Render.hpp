#pragma once

// Optional video rendering through the "FFmpeg API" mod (eclipse.ffmpeg-api).
// Compiles to a no-op if the option is off, on iOS, or if the headers aren't found.

#include <Geode/Geode.hpp>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <memory>
#include <vector>

#if defined(ALPHABOT_RENDER) && !defined(GEODE_IS_IOS)
    #if __has_include(<eclipse.ffmpeg-api/include/events.hpp>)
        #include <eclipse.ffmpeg-api/include/events.hpp>
        #define AB_HAS_FFMPEG 1
    #elif __has_include(<eclipse.ffmpeg-api/events.hpp>)
        #include <eclipse.ffmpeg-api/events.hpp>
        #define AB_HAS_FFMPEG 1
    #endif
#endif

namespace ab {

constexpr int kRenderFps = 60;

class Renderer {
    geode::Ref<cocos2d::CCRenderTexture> m_rt;
    std::vector<uint8_t> m_buf;
    std::filesystem::path m_out;
    bool m_started = false;
#ifdef AB_HAS_FFMPEG
    std::unique_ptr<ffmpeg::events::Recorder> m_rec;
#endif

public:
    static bool available() {
#ifdef AB_HAS_FFMPEG
        return geode::Loader::get()->isModLoaded("eclipse.ffmpeg-api");
#else
        return false;
#endif
    }

    void begin(std::filesystem::path out) {
        m_out = std::move(out);
        m_started = false;
    }

    // Renders the current scene into a texture and feeds it to ffmpeg.
    // Returns false if rendering failed and should be aborted.
    bool capture() {
#ifdef AB_HAS_FFMPEG
        using namespace geode::prelude;

        auto scene = CCDirector::get()->getRunningScene();
        if (!scene) return true;

        if (!m_rt) {
            auto win = CCDirector::get()->getWinSize();
            m_rt = CCRenderTexture::create(
                static_cast<int>(win.width), static_cast<int>(win.height),
                kCCTexture2DPixelFormat_RGBA8888, 0x88F0 /* depth24 + stencil8 */
            );
            if (!m_rt) return false;
        }

        m_rt->beginWithClear(0, 0, 0, 1);
        scene->visit();
        m_rt->end();

        auto img = m_rt->newCCImage(true);
        if (!img) return false;

        // h264 wants even dimensions
        int w = img->getWidth() & ~1;
        int h = img->getHeight() & ~1;
        int stride = img->getWidth() * 4;
        m_buf.resize(static_cast<size_t>(w) * h * 4);
        auto src = img->getData();
        for (int y = 0; y < h; y++) {
            std::memcpy(&m_buf[static_cast<size_t>(y) * w * 4], src + static_cast<size_t>(y) * stride, static_cast<size_t>(w) * 4);
        }
        img->release();

        if (!m_rec) {
            using namespace ffmpeg;
            m_rec = std::make_unique<ffmpeg::events::Recorder>();
            RenderSettings s;
            s.m_pixelFormat = PixelFormat::RGB0;
            s.m_codec = "libx264";
            s.m_bitrate = 16'000'000;
            s.m_width = w;
            s.m_height = h;
            s.m_fps = kRenderFps;
            s.m_outputFile = m_out.string();
            auto res = m_rec->init(s);
            if (res.isErr()) {
                log::error("Alpha Bot: ffmpeg init failed: {}", res.unwrapErr());
                m_rec.reset();
                return false;
            }
            m_started = true;
        }

        m_rec->writeFrame(m_buf);
        return true;
#else
        return false;
#endif
    }

    void stop() {
#ifdef AB_HAS_FFMPEG
        if (m_rec) {
            m_rec->stop();
            m_rec.reset();
            geode::Notification::create("Render saved: " + m_out.filename().string(), geode::NotificationIcon::Success)->show();
        }
#endif
        m_rt = nullptr;
        m_started = false;
    }

    std::filesystem::path const& output() const { return m_out; }
};

}
