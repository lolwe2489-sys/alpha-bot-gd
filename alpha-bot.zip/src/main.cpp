#include <Geode/Geode.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include "Bot.hpp"
#include "Menu.hpp"

using namespace geode::prelude;
using namespace ab;

static bool isPlayLayer(GJBaseGameLayer* layer) {
    auto pl = PlayLayer::get();
    return pl && static_cast<GJBaseGameLayer*>(pl) == layer;
}

// ---------------------------------------------------------------------------
// FRAME FIX + rendering: control how time is fed to the game
// ---------------------------------------------------------------------------
class $modify(ABScheduler, CCScheduler) {
    void update(float dt) {
        auto& b = Bot::get();

        // offline render: one fixed step per video frame, then grab the picture
        if (b.rendering) {
            b.stepped = false;
            CCScheduler::update(1.f / kRenderFps);
            if (b.stepped && !b.renderer.capture()) {
                Notification::create("Render failed", NotificationIcon::Error)->show();
                b.endSession();
            }
            return;
        }

        // frame fix: constant 60 Hz update step while recording / replaying,
        // so the physics sees identical timing no matter the screen's FPS
        if (b.frameFix && b.mode != Mode::Idle && PlayLayer::get()) {
            b.acc += dt;
            int n = 0;
            while (b.acc >= kStep && n < 4) {
                CCScheduler::update(kStep);
                b.acc -= kStep;
                n++;
            }
            if (n == 4) b.acc = 0.f;  // don't spiral after a lag spike
            return;
        }

        b.acc = 0.f;
        CCScheduler::update(dt);
    }
};

// ---------------------------------------------------------------------------
// Step-accurate input recording / playback
// ---------------------------------------------------------------------------
class $modify(ABGameLayer, GJBaseGameLayer) {
    void processCommands(float dt) {
        if (!isPlayLayer(this)) {
            GJBaseGameLayer::processCommands(dt);
            return;
        }

        auto& b = Bot::get();

        if (b.mode == Mode::Play) {
            // inputs for this step go in *before* the step runs
            b.injecting = true;
            while (b.cursor < b.actions.size() && b.actions[b.cursor].frame <= b.frame) {
                auto a = b.actions[b.cursor++];
                this->handleButton(a.down, a.button, a.p1);
            }
            b.injecting = false;

            // input fix: hand control back and never leave a button stuck
            if (!b.finished && b.cursor >= b.actions.size()) {
                b.finished = true;
                if (b.inputFix) b.releaseAll(this);
            }
        }

        GJBaseGameLayer::processCommands(dt);
        b.frame++;
        b.stepped = true;

        if (b.mode == Mode::Play && b.rendering && b.finished && b.frame > b.lastFrame() + kTail) {
            b.endSession();
        } else if (b.mode != Mode::Idle && b.frame % 30 == 0) {
            b.updateHud();
        }
    }

    void handleButton(bool down, int button, bool isPlayer1) {
        if (isPlayLayer(this)) {
            auto& b = Bot::get();

            // live taps are ignored while a macro is still playing
            if (b.mode == Mode::Play && !b.injecting && b.cursor < b.actions.size()) return;

            // input fix: drop duplicate presses / stray releases
            if (!b.accept(down, button, isPlayer1)) return;

            if (b.mode == Mode::Record && !b.injecting) {
                b.actions.push_back({b.frame, static_cast<uint8_t>(button), down, isPlayer1});
            }
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }
};

// ---------------------------------------------------------------------------
// Attempt lifecycle, practice checkpoints, HUD
// ---------------------------------------------------------------------------
class $modify(ABPlayLayer, PlayLayer) {
    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();

        auto& b = Bot::get();
        b.fullReset();

        if (m_uiLayer) {
            auto win = CCDirector::get()->getWinSize();
            auto label = CCLabelBMFont::create("", "bigFont.fnt");
            label->setScale(0.3f);
            label->setOpacity(150);
            label->setAnchorPoint({0, 1});
            label->setPosition({28.f, win.height - 22.f});
            label->setVisible(false);
            m_uiLayer->addChild(label, 100);
            b.hud = label;
        }
    }

    void resetLevel() {
        PlayLayer::resetLevel();

        auto& b = Bot::get();
        bool fromCheckpoint = m_isPracticeMode && m_checkpointArray && m_checkpointArray->count() > 0;
        if (!fromCheckpoint) b.resetAttempt();

        // replays are not allowed to save progress
        if (b.mode == Mode::Play) m_isTestMode = true;
    }

    CheckpointObject* createCheckpoint() {
        auto cp = PlayLayer::createCheckpoint();
        if (cp) {
            auto& b = Bot::get();
            b.checkpoints[static_cast<void*>(cp)] = b.frame;
        }
        return cp;
    }

    void loadFromCheckpoint(CheckpointObject* cp) {
        PlayLayer::loadFromCheckpoint(cp);

        auto& b = Bot::get();
        auto it = b.checkpoints.find(static_cast<void*>(cp));
        if (it != b.checkpoints.end()) b.rewind(it->second);
    }

    void levelComplete() {
        auto& b = Bot::get();
        if (b.mode == Mode::Record && !b.actions.empty() && b.save()) {
            Notification::create("Alpha Bot: macro autosaved", NotificationIcon::Success)->show();
        }
        b.endSession();
        PlayLayer::levelComplete();
    }

    void onQuit() {
        Bot::get().fullReset();
        PlayLayer::onQuit();
    }
};

// ---------------------------------------------------------------------------
// α button in the pause menu
// ---------------------------------------------------------------------------
class $modify(ABPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();

        auto win = CCDirector::get()->getWinSize();

        CCNode* icon = CCSprite::create("alpha-icon.png"_spr);
        if (icon) {
            icon->setScale(36.f / icon->getContentSize().width);  // comfortable thumb target
        } else {
            icon = ButtonSprite::create("a");
        }

        auto btn = CCMenuItemSpriteExtra::create(icon, this, menu_selector(ABPauseLayer::onAlpha));

        auto menu = CCMenu::create();
        menu->setID("alpha-bot-menu"_spr);
        menu->setPosition({0, 0});
        btn->setPosition({win.width - 36.f, win.height * 0.32f});
        menu->addChild(btn);
        this->addChild(menu, 10);
    }

    void onAlpha(CCObject*) {
        AlphaMenu::create(this)->show();
    }
};
