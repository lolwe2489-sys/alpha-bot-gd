#pragma once

#include <Geode/ui/Popup.hpp>
#include "Bot.hpp"

namespace ab {

// Minimal black menu: white outlines, no fancy sprites. Big touch targets.
class AlphaMenu : public Popup {
protected:
    PauseLayer* m_pause = nullptr;
    CCLabelBMFont* m_status = nullptr;
    CCLabelBMFont* m_file = nullptr;
    std::vector<fs::path> m_files;
    size_t m_idx = 0;

    // ---------- tiny UI helpers ----------
    static void fitLabel(CCLabelBMFont* lbl, float maxW) {
        lbl->setScale(1.f);
        float s = std::min(0.45f, (maxW - 10.f) / std::max(1.f, lbl->getContentSize().width));
        lbl->setScale(s);
    }

    static CCNode* makeBox(float w, float h, std::string const& text) {
        auto box = CCNode::create();
        box->setContentSize({w, h});

        auto outer = CCLayerColor::create({255, 255, 255, 255}, w, h);
        auto inner = CCLayerColor::create({0, 0, 0, 255}, w - 3.f, h - 3.f);
        inner->setPosition({1.5f, 1.5f});
        box->addChild(outer);
        box->addChild(inner);

        auto lbl = CCLabelBMFont::create(text.c_str(), "bigFont.fnt");
        lbl->setTag(1);
        lbl->setPosition({w / 2, h / 2});
        fitLabel(lbl, w);
        box->addChild(lbl);
        return box;
    }

    static void setBoxText(CCMenuItemSpriteExtra* btn, std::string const& text) {
        auto box = btn->getNormalImage();
        if (!box) return;
        if (auto lbl = typeinfo_cast<CCLabelBMFont*>(box->getChildByTag(1))) {
            lbl->setString(text.c_str());
            fitLabel(lbl, box->getContentSize().width);
        }
    }

    CCMenuItemSpriteExtra* addBtn(std::string const& text, float x, float y, SEL_MenuHandler sel, float w = 100.f, float h = 26.f) {
        auto btn = CCMenuItemSpriteExtra::create(makeBox(w, h, text), this, sel);
        m_buttonMenu->addChildAtPosition(btn, Anchor::Center, {x, y});
        return btn;
    }

    static std::string onOff(char const* name, bool on) {
        return fmt::format("{}: {}", name, on ? "ON" : "OFF");
    }

    // ---------- setup ----------
    bool init(PauseLayer* pause) {
        constexpr float W = 360.f, H = 250.f;
        if (!Popup::init(W, H)) return false;

        m_pause = pause;
        if (m_bgSprite) m_bgSprite->setVisible(false);
        if (m_closeBtn) m_closeBtn->setVisible(false);

        // black panel with a white outline
        auto border = CCLayerColor::create({255, 255, 255, 255}, W + 3.f, H + 3.f);
        border->ignoreAnchorPointForPosition(false);
        border->setAnchorPoint({0.5f, 0.5f});
        m_mainLayer->addChildAtPosition(border, Anchor::Center, {0, 0}, false);
        border->setZOrder(-2);

        auto panel = CCLayerColor::create({0, 0, 0, 255}, W, H);
        panel->ignoreAnchorPointForPosition(false);
        panel->setAnchorPoint({0.5f, 0.5f});
        m_mainLayer->addChildAtPosition(panel, Anchor::Center, {0, 0}, false);
        panel->setZOrder(-1);

        // title: α icon + name
        if (auto icon = CCSprite::create("alpha-icon.png"_spr)) {
            icon->setScale(24.f / icon->getContentSize().width);
            m_mainLayer->addChildAtPosition(icon, Anchor::Center, {-62.f, 102.f});
        }
        auto title = CCLabelBMFont::create("Alpha Bot", "bigFont.fnt");
        title->setScale(0.55f);
        m_mainLayer->addChildAtPosition(title, Anchor::Center, {8.f, 102.f});

        m_status = CCLabelBMFont::create("", "chatFont.fnt");
        m_status->setScale(0.8f);
        m_mainLayer->addChildAtPosition(m_status, Anchor::Center, {0, 74.f});

        addBtn("x", W / 2 - 22.f, H / 2 - 22.f, menu_selector(AlphaMenu::onCloseBtn), 28.f, 28.f);

        // main actions
        addBtn("Record", -112.f, 44.f, menu_selector(AlphaMenu::onRecord), 104.f);
        addBtn("Replay", 0.f, 44.f, menu_selector(AlphaMenu::onReplay), 104.f);
        addBtn("Stop", 112.f, 44.f, menu_selector(AlphaMenu::onStop), 104.f);

        // file picker
        addBtn("<", -150.f, 12.f, menu_selector(AlphaMenu::onPrev), 34.f);
        addBtn(">", 150.f, 12.f, menu_selector(AlphaMenu::onNext), 34.f);
        m_file = CCLabelBMFont::create("", "chatFont.fnt");
        m_file->setScale(0.8f);
        m_mainLayer->addChildAtPosition(m_file, Anchor::Center, {0, 12.f});

        addBtn("Save", -112.f, -20.f, menu_selector(AlphaMenu::onSave), 104.f);
        addBtn("Load", 0.f, -20.f, menu_selector(AlphaMenu::onLoad), 104.f);
        addBtn("Delete", 112.f, -20.f, menu_selector(AlphaMenu::onDelete), 104.f);

        // fixes
        auto& bot = Bot::get();
        auto f1 = addBtn(onOff("Frame fix", bot.frameFix), -116.f, -54.f, menu_selector(AlphaMenu::onToggle), 108.f);
        auto f2 = addBtn(onOff("Input fix", bot.inputFix), 0.f, -54.f, menu_selector(AlphaMenu::onToggle), 108.f);
        auto f3 = addBtn(onOff("Practice fix", bot.practiceFix), 116.f, -54.f, menu_selector(AlphaMenu::onToggle), 108.f);
        f1->setTag(1);
        f2->setTag(2);
        f3->setTag(3);

        // optional render
        std::string renderText = Renderer::available() ? onOff("Render video", bot.renderOpt) : "Render: needs FFmpeg API";
        auto r = addBtn(renderText, 0.f, -88.f, menu_selector(AlphaMenu::onRender), 220.f);
        r->setTag(4);

        auto credits = CCLabelBMFont::create("by idk  |  inspired by zBot (fig)", "chatFont.fnt");
        credits->setScale(0.55f);
        credits->setOpacity(150);
        m_mainLayer->addChildAtPosition(credits, Anchor::Center, {0, -114.f});

        this->refreshFiles();
        return true;
    }

    // ---------- helpers ----------
    void closeMenu() {
        this->setKeypadEnabled(false);
        this->setTouchEnabled(false);
        this->removeFromParentAndCleanup(true);
    }

    void refreshFiles() {
        m_files = Bot::get().listReplays();
        if (m_idx >= m_files.size()) m_idx = m_files.empty() ? 0 : m_files.size() - 1;
        this->refresh();
    }

    void refresh() {
        auto& bot = Bot::get();
        char const* mode = bot.mode == Mode::Record ? "RECORDING" : bot.mode == Mode::Play ? "REPLAYING" : "IDLE";
        m_status->setString(fmt::format("{}  |  {} inputs", mode, bot.actions.size()).c_str());

        if (m_files.empty()) {
            m_file->setString("no saved macros for this level");
        } else {
            auto stem = m_files[m_idx].stem().string();
            if (stem.size() > 15) stem = stem.substr(stem.size() - 15);
            m_file->setString(fmt::format("{}/{}  {}", m_idx + 1, m_files.size(), stem).c_str());
        }
    }

    void restartLevel() {
        // closing the menu may destroy `this`, so copy what we need first
        auto pause = m_pause;
        auto pl = PlayLayer::get();
        bool practice = pl && pl->m_isPracticeMode;
        this->closeMenu();
        if (!pause) return;
        if (practice) pause->onRestartFull(nullptr);
        else pause->onRestart(nullptr);
    }

    // ---------- callbacks ----------
    void onCloseBtn(CCObject*) { this->closeMenu(); }

    void onRecord(CCObject*) {
        Bot::get().begin(Mode::Record);
        this->restartLevel();
    }

    void onReplay(CCObject*) {
        auto& bot = Bot::get();
        if (bot.actions.empty()) {
            Notification::create("Record or load a macro first", NotificationIcon::Error)->show();
            return;
        }
        bot.begin(Mode::Play);
        this->restartLevel();
    }

    void onStop(CCObject*) {
        Bot::get().endSession();
        this->refresh();
    }

    void onSave(CCObject*) {
        if (Bot::get().save()) {
            Notification::create("Macro saved", NotificationIcon::Success)->show();
            this->refreshFiles();
            if (!m_files.empty()) m_idx = m_files.size() - 1;
            this->refresh();
        } else {
            Notification::create("Nothing to save", NotificationIcon::Error)->show();
        }
    }

    void onLoad(CCObject*) {
        if (m_files.empty()) {
            Notification::create("No macro selected", NotificationIcon::Error)->show();
            return;
        }
        auto& bot = Bot::get();
        if (bot.load(m_files[m_idx])) {
            bot.endSession();
            Notification::create(fmt::format("Loaded {} inputs", bot.actions.size()), NotificationIcon::Success)->show();
        } else {
            Notification::create("Failed to load macro", NotificationIcon::Error)->show();
        }
        this->refresh();
    }

    void onDelete(CCObject*) {
        if (m_files.empty()) return;
        Bot::get().remove(m_files[m_idx]);
        this->refreshFiles();
    }

    void onPrev(CCObject*) {
        if (m_files.empty()) return;
        m_idx = (m_idx + m_files.size() - 1) % m_files.size();
        this->refresh();
    }

    void onNext(CCObject*) {
        if (m_files.empty()) return;
        m_idx = (m_idx + 1) % m_files.size();
        this->refresh();
    }

    void onToggle(CCObject* sender) {
        auto btn = static_cast<CCMenuItemSpriteExtra*>(sender);
        auto& bot = Bot::get();
        switch (btn->getTag()) {
            case 1: bot.frameFix = !bot.frameFix; setBoxText(btn, onOff("Frame fix", bot.frameFix)); break;
            case 2: bot.inputFix = !bot.inputFix; setBoxText(btn, onOff("Input fix", bot.inputFix)); break;
            case 3: bot.practiceFix = !bot.practiceFix; setBoxText(btn, onOff("Practice fix", bot.practiceFix)); break;
        }
        bot.saveOptions();
    }

    void onRender(CCObject* sender) {
        if (!Renderer::available()) {
            Notification::create("Install the FFmpeg API mod (Windows/macOS/Android)", NotificationIcon::Error)->show();
            return;
        }
        auto& bot = Bot::get();
        bot.renderOpt = !bot.renderOpt;
        setBoxText(static_cast<CCMenuItemSpriteExtra*>(sender), onOff("Render video", bot.renderOpt));
    }

public:
    static AlphaMenu* create(PauseLayer* pause) {
        auto ret = new AlphaMenu();
        if (ret->init(pause)) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

}
