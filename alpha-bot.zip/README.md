# Alpha Bot

Минималистичный бот Geometry Dash (запись + реплей) для Geode. Win / macOS / iOS / Android.
Авторы: idk; вдохновлён zBot (fig). Код независимый, кода zBot здесь нет.

## Структура
- `src/main.cpp`  — все хуки (ввод, шаг времени, чекпоинты, кнопка в паузе)
- `src/Bot.hpp`   — состояние бота, фиксы, сохранение/загрузка `.abr`
- `src/Menu.hpp`  — чёрное минималистичное меню
- `src/Render.hpp`— необязательный рендер через FFmpeg API (Win/macOS/Android)

## Фиксы
- Frame fix — фиксированный шаг 60 Гц при записи/реплее (результат не зависит от FPS)
- Input fix — отбрасывает дубли нажатий, блокирует касания во время реплея, отпускает зажатые кнопки
- Practice fix — откат на чекпоинт обрезает макрос

## Сборка (GitHub Actions)
1. Залей папку в репозиторий GitHub.
2. Actions -> "Build Alpha Bot" -> Run workflow.
3. Скачай артефакт `Alpha-Bot` -> `idk.alpha-bot.geode`.

Локально: `geode build` (нужны Geode CLI, C++23-компилятор).
Если сборка падает на рендере: `geode build -- -DALPHABOT_RENDER=OFF`.
