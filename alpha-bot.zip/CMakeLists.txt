cmake_minimum_required(VERSION 3.21)
set(CMAKE_CXX_STANDARD 23)           # Geode v5 requires C++23
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_OSX_DEPLOYMENT_TARGET "10.15")
set(CMAKE_CXX_VISIBILITY_PRESET hidden)

project(AlphaBot VERSION 1.0.0)

# Video rendering through eclipse.ffmpeg-api (Windows / macOS / Android).
# If the build fails because of the ffmpeg-api headers, configure with -DALPHABOT_RENDER=OFF
option(ALPHABOT_RENDER "Enable optional video rendering via ffmpeg-api" ON)

file(GLOB SOURCES CONFIGURE_DEPENDS src/*.cpp)
add_library(${PROJECT_NAME} SHARED ${SOURCES})

if (ALPHABOT_RENDER)
    target_compile_definitions(${PROJECT_NAME} PRIVATE ALPHABOT_RENDER=1)
endif()

if (NOT DEFINED ENV{GEODE_SDK})
    message(FATAL_ERROR "Unable to find Geode SDK! Please define GEODE_SDK environment variable to point to Geode")
else()
    message(STATUS "Found Geode: $ENV{GEODE_SDK}")
endif()

add_subdirectory($ENV{GEODE_SDK} ${CMAKE_CURRENT_BINARY_DIR}/geode)
setup_geode_mod(${PROJECT_NAME})
